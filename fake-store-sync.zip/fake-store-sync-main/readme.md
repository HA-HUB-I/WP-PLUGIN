
<div align='center'>

![sync product with category ,price, image](image.png)  
*▲ sync product with category ,price, image*

</div>

✨ 