<div class="wrap">
    <h1>Fake Store Sync</h1>
    <form method="post">
        <?php wp_nonce_field('fake_store_sync'); ?>
        <input type="submit" name="fake_store_sync_submit" class="button button-primary" value="Синхронизирай сега">
    </form>
</div> 
